finish view Cases
finish add cses